package com.poc.health.EnrollesDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnrollesDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnrollesDemoApplication.class, args);
	}

}
